Created by Codrops
License (if not mentioned otherwise in the files): http://tympanus.net/codrops/licensing/

Background Pattern(s) from http://subtlepatterns.com/
http://creativecommons.org/licenses/by-sa/3.0/deed.en_US

normalize.css by Nicolas Gallagher: http://github.com/necolas/normalize.css

Images by geishaboy500
http://www.flickr.com/photos/geishaboy500/ 
http://creativecommons.org/licenses/by/2.0/deed.en




